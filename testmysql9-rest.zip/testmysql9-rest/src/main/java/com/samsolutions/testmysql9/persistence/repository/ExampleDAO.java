package com.samsolutions.testmysql9.persistence.repository;

import com.samsolutions.testmysql9.persistence.entity.Example;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 * @author The Great Tool
 * @since 21.06.2017
 */
@Repository
public interface ExampleDAO extends CrudRepository<Example, Long> {
}
