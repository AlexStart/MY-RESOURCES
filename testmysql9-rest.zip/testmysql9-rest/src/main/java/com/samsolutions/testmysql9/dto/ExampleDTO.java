package com.samsolutions.testmysql9.dto;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * @author The Great Tool
 * @since 21.06.2017
 */
@Setter
@Getter
public class ExampleDTO implements Serializable {

    private Long id;
    private String data;

    public ExampleDTO () {
    }

}
