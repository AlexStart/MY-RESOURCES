package com.samsolutions.testmysql9.persistence.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * @author The Great Tool
 * @since 21.06.2017
 */
@Data
@Entity
public class Example {

    @Id
    @GeneratedValue
    private Long id;

    private String data;
}
