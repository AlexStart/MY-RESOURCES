package com.samsolutions.testmysql9.controller;

import com.samsolutions.testmysql9.dto.ExampleDTO;
import com.samsolutions.testmysql9.service.ExampleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Created by gladivs on 21.06.2017.
 */
@RestController
@RequestMapping("/api/example")
public class ExampleController {
    @Autowired
    ExampleService<ExampleDTO, Long> service;

    @GetMapping("/{id}")
    public ResponseEntity<?> find (@PathVariable("id") Long id) {
        ExampleDTO exampleDTO = service.find(id);
        if (exampleDTO == null) {
            return new ResponseEntity(String.format("ExampleDTO with id {0} is not found.", id), HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<ExampleDTO>(exampleDTO, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<?> findAll () {
        List<ExampleDTO> exampleDTOs = service.findAll();
        if (exampleDTOs == null || exampleDTOs.size() == 0) {
            return new ResponseEntity(String.format("No ExampleDTO is found."), HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<List<ExampleDTO>>(exampleDTOs, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<?> create (ExampleDTO dto) {
        if (dto == null) {
            return new ResponseEntity(String.format("Unable to create new ExampleDTO."), HttpStatus.BAD_REQUEST);
        }
        ExampleDTO exampleDTO = service.save(dto);
        if (exampleDTO == null) {
            return new ResponseEntity(String.format("Unable to create new ExampleDTO."), HttpStatus.CONFLICT);
        }
        HttpHeaders headers = new HttpHeaders();
       // headers.setLocation(ucBuilder.path("/api/example/{id}").buildAndExpand(exampleDTO.getId()).toUri());
       // return new ResponseEntity<String>(headers, HttpStatus.CREATED);
        return new ResponseEntity<ExampleDTO>(exampleDTO, headers, HttpStatus.CREATED);
    }

    @PutMapping
    public ResponseEntity<?> update (ExampleDTO dto) {
        ExampleDTO exampleDTO = service.update(dto);
        if (exampleDTO == null) {
            return new ResponseEntity(String.format("Unable to upate ExampleDTO."), HttpStatus.CONFLICT);
        }
        return new ResponseEntity<ExampleDTO>(exampleDTO, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete (@PathVariable("id") Long id) {
        service.delete(id);
        ExampleDTO exampleDTO = service.find(id);
        if (exampleDTO != null) {
            return new ResponseEntity(String.format("Unable to delete ExampleDTO with id {0}.", id), HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<ExampleDTO>(HttpStatus.OK);
    }
}
