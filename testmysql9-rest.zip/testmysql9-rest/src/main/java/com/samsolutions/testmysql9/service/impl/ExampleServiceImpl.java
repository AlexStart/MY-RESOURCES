package com.samsolutions.testmysql9.service.impl;

import com.samsolutions.testmysql9.dto.ExampleDTO;
import com.samsolutions.testmysql9.service.ExampleService;
import com.samsolutions.testmysql9.converter.ExampleConverter;
import com.samsolutions.testmysql9.persistence.repository.ExampleDAO;
import com.samsolutions.testmysql9.persistence.entity.Example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * @author The Great Tool
 * @since 21.06.2017
 */
@Service
@Transactional
public class ExampleServiceImpl implements ExampleService<ExampleDTO, Long> {
    @Autowired
    private ExampleDAO exampleDAO;
    @Autowired
    private ExampleConverter exampleConverter;


    @Override
    public ExampleDTO save(ExampleDTO dto) {
        Example entity = exampleDAO.save(convertDTOToEntity(dto));
        return exampleConverter.convertEntityToDTO (entity);
    }

    @Override
    public ExampleDTO update(ExampleDTO dto) {
        Example entity = exampleDAO.save(convertDTOToEntity(dto));
        return exampleConverter.convertEntityToDTO (entity);
    }

    @Transactional(readOnly = true)
    @Override
    public ExampleDTO find(Long id) {
        return exampleConverter.convertEntityToDTO (exampleDAO.findOne(id));
    }

    @Transactional(readOnly = true)
    @Override
    public List<ExampleDTO> findAll() {
        return exampleConverter.convertEntityListToDTOList((List<Example>) exampleDAO.findAll());
    }

    @Override
    public void delete(Long id) {
        exampleDAO.delete(id);
    }

    // TODO : Place these converters into separate class.
    private ExampleDTO convertEntityToDTO (Example entity) {
        ExampleDTO dto = new ExampleDTO();
        dto.setId(entity.getId());
        dto.setData(entity.getData());
        return dto;
    }

    private List<ExampleDTO> convertEntityListToDTOList (List<Example> entities) {
        List<ExampleDTO> dtos = new ArrayList<>();
        for(Example entity : entities) {
            dtos.add(convertEntityToDTO(entity));
        }
        return dtos;
    }

    private Example convertDTOToEntity (ExampleDTO dto) {
        Example entity = new Example();
        entity.setId(dto.getId());
        entity.setData(dto.getData());
        return entity;
    }
}

