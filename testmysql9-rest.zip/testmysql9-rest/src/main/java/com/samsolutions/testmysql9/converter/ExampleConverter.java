package com.samsolutions.testmysql9.converter;

import com.samsolutions.testmysql9.persistence.entity.Example;
import com.samsolutions.testmysql9.dto.ExampleDTO;

import java.util.List;

/**
 * @author The Great Tool
 * @since 21.06.2017
 */
public interface ExampleConverter <D extends ExampleDTO, P extends Example>  {
    D convertEntityToDTO (P entity);

    List<D> convertEntityListToDTOList (List<P> entities);

    P convertDTOToEntity (D dto);
}
