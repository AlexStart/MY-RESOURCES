package com.samsolutions.testmysql9.converter.impl;

import com.samsolutions.testmysql9.persistence.entity.Example;
import com.samsolutions.testmysql9.dto.ExampleDTO;
import com.samsolutions.testmysql9.converter.ExampleConverter;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @author The Great Tool
 * @since 21.06.2017
 */
@Component
public class ExampleConverterImpl implements ExampleConverter <ExampleDTO, Example>  {
        public ExampleDTO convertEntityToDTO (Example entity) {
            if(entity == null) {
               return null;
            }
            ExampleDTO dto = new ExampleDTO();
            dto.setId(entity.getId());
            dto.setData(entity.getData());
            return dto;
        }

        public List<ExampleDTO> convertEntityListToDTOList (List<Example> entities) {
            List<ExampleDTO> dtos = new ArrayList<>();
            for(Example entity : entities) {
                dtos.add(convertEntityToDTO(entity));
            }
            return dtos;
        }

        public Example convertDTOToEntity (ExampleDTO dto) {
            if(dto == null) {
               return null;
            }
            Example entity = new Example();
            entity.setId(dto.getId());
            entity.setData(dto.getData());
            return entity;
        }
}
