package com.samsolutions.testmysql9.service;

import com.samsolutions.testmysql9.dto.ExampleDTO;

import java.io.Serializable;
import java.util.List;

/**
 * @author The Great Tool
 * @since 21.06.2017
 */
public interface ExampleService <T extends ExampleDTO, K extends Serializable>  {
    T save(T dto);
    T update(T dto);
    T find(K id);
    List<T> findAll();
    void delete(K id);
}
