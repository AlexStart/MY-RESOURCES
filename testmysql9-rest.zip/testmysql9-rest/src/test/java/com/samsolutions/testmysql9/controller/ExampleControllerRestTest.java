package com.samsolutions.testmysql9.controller;

import com.samsolutions.testmysql9.dto.ExampleDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * @author The Great Tool
 * @since 20.06.2017
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@RunWith(SpringRunner.class)
//@ComponentScan(basePackages = "com.samsolutions.testmysql9.*")
//@AutoConfigureMockMvc
public class ExampleControllerRestTest {

    /*@Autowired
    MockMvc mockMvc;*/
    @Autowired
    private TestRestTemplate restTemplate;
    private ExampleDTO exampleDTO;


    @Before
    public void setUp() {
        exampleDTO = new ExampleDTO();
        exampleDTO.setData("some DTO");

        deleteAll();
    }

    @Test
    public void create() {
       /* this.mockMvc.perform(get("/").accept(MediaType.parseMediaType("application/json;charset=UTF-8")))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"));*/
        ResponseEntity<ExampleDTO> createResponseEntity = restTemplate.postForEntity("/api/example", exampleDTO, ExampleDTO.class);
        assertThat(HttpStatus.CREATED).isEqualTo(createResponseEntity.getStatusCode());
        assertThat(createResponseEntity.getBody()).isNotNull();
        assertThat(createResponseEntity.getBody().getData()).isEqualTo(exampleDTO.getData());
        assertThat(createResponseEntity.getBody().getId()).isNotNull();
    }

    @Test
    public void read() {
        ResponseEntity<ExampleDTO> createResponseEntity = restTemplate.postForEntity("/api/example", exampleDTO, ExampleDTO.class);
        ExampleDTO createdDTO = createResponseEntity.getBody();
        assertThat(createResponseEntity.getBody()).isNotNull();
        assertThat(createResponseEntity.getBody().getId()).isNotNull();

        ResponseEntity<ExampleDTO> findResponseEntity = findExampleDTO(getUrl(String.valueOf(createdDTO.getId())), ExampleDTO.class);
        assertThat(findResponseEntity.getBody()).isNotNull();
        assertThat(findResponseEntity.getBody().getData()).isEqualTo(exampleDTO.getData());
        assertThat(findResponseEntity.getBody().getId()).isNotNull();
    }

    //TO DO :
    @Test
    public void readAll() {
        ResponseEntity<ExampleDTO> createResponseEntity = restTemplate.getForEntity("/api/example", ExampleDTO.class);
        ExampleDTO createdDTO = createResponseEntity.getBody();
        assertThat(createResponseEntity.getBody()).isNotNull();
        assertThat(createResponseEntity.getBody().getId()).isNotNull();

        ResponseEntity<ExampleDTO> findResponseEntity = findExampleDTO(getUrl(String.valueOf(createdDTO.getId())), ExampleDTO.class);
        assertThat(findResponseEntity.getBody()).isNotNull();
        assertThat(findResponseEntity.getBody().getData()).isEqualTo(exampleDTO.getData());
        assertThat(findResponseEntity.getBody().getId()).isNotNull();
    }

     @Test
     public void update() {
         ResponseEntity<ExampleDTO> createResponseEntity = restTemplate.postForEntity("/api/example", exampleDTO, ExampleDTO.class);
         ExampleDTO createdDTO = createResponseEntity.getBody();
         assertThat(createdDTO).isNotNull();

         createdDTO.setData("updated DTO");
         restTemplate.put("/api/example", createdDTO);

         ResponseEntity<ExampleDTO> updateResponseEntity = findExampleDTO(getUrl(String.valueOf(createdDTO.getId())), ExampleDTO.class);
         assertThat(updateResponseEntity.getBody()).isNotNull();
         assertThat(updateResponseEntity.getBody().getData()).isEqualTo(createdDTO.getData());
         assertThat(updateResponseEntity.getBody().getId()).isEqualTo(createdDTO.getId());
     }

     // TO DO : restTemplate.patch("/api/example", createdDTO);
     @Test
     public void patch() {
         ResponseEntity<ExampleDTO> createResponseEntity = restTemplate.postForEntity("/api/example", exampleDTO, ExampleDTO.class);
         ExampleDTO createdDTO = createResponseEntity.getBody();
         assertThat(createdDTO).isNotNull();

         createdDTO.setData("patched DTO");
         restTemplate.patch("/api/example", createdDTO);

         ResponseEntity<ExampleDTO> updateResponseEntity = findExampleDTO(getUrl(String.valueOf(createdDTO.getId())), ExampleDTO.class);
         assertThat(updateResponseEntity.getBody()).isNotNull();
         assertThat(updateResponseEntity.getBody().getData()).isEqualTo(createdDTO.getData());
         assertThat(updateResponseEntity.getBody().getId()).isEqualTo(createdDTO.getId());
     }


     @Test
      public void delete() {
          ResponseEntity<ExampleDTO> createResponseEntity = restTemplate.postForEntity("/api/example", exampleDTO, ExampleDTO.class);
          ExampleDTO createdDTO = createResponseEntity.getBody();
          assertThat(createdDTO).isNotNull();

          restTemplate.delete("/api/example/{0}", createdDTO.getId());

          ResponseEntity<ExampleDTO> deleteResponseEntity = findExampleDTO(getUrl(String.valueOf(createdDTO.getId())), ExampleDTO.class);
          assertThat(deleteResponseEntity.getBody()).isNull();
      }

      @Test
      public void deleteAll() {
         //TO DO :
      }

      @Before
      public void tearDownp() {
         deleteAll();
      }

    /*private ResponseEntity<ExampleDTO> createExampleDTO(String url, ExampleDTO dto, Class<ExampleDTO> dtoClazz){
         return restTemplate.postForEntity(url, dto, dtoClazz);
    }*/

    private ResponseEntity<ExampleDTO> findExampleDTO(String url, Class<ExampleDTO> dtoClazz){
        return restTemplate.getForEntity(url, dtoClazz);
    }

    private String getUrl(String pathVar){
        return String.format("/api/example/%s", pathVar);
    }
}
