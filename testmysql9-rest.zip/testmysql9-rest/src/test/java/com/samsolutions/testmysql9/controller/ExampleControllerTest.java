package com.samsolutions.testmysql9.controller;

import com.samsolutions.testmysql9.dto.ExampleDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * @author The Great Tool
 * @since 20.06.2017
 */
//@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = DemoApplicationTests.class)
@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
public class ExampleControllerTest {

    /*@Autowired
    MockMvc mockMvc;*/
    private TestRestTemplate restTemplate;
    private ExampleDTO exampleDTO;


    @Before
    public void setUp() {
        restTemplate = new TestRestTemplate();
        exampleDTO = new ExampleDTO();
        exampleDTO.setData("some DTO");
    }

    @Test
    public void creates() {
       /* this.mockMvc.perform(get("/").accept(MediaType.parseMediaType("application/json;charset=UTF-8")))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"));*/
        ResponseEntity<ExampleDTO> responseEntity = restTemplate.postForEntity("/api/example", exampleDTO, ExampleDTO.class);
        assertThat(HttpStatus.OK).isEqualTo(responseEntity.getStatusCode());
        assertThat(responseEntity.getBody().getData()).isEqualTo(exampleDTO.getData());
        assertThat(responseEntity.getBody().getId()).isNotNull();
    }

    @Test
    public void reads() {
         //ExampleDTO savedExampleDTO = service.save(exampleDTO);
         //final ExampleDTO foundExampleDTO = service.find(savedExampleDTO.getId());

         //assertThat(foundExampleDTO).isNotNull();
         //assertThat(foundExampleDTO.getId()).isEqualTo(savedExampleDTO.getId());
    }

     @Test
     public void updates() {
          /*final ExampleDTO savedExampleDTO = service.save(exampleDTO);
          savedExampleDTO.setData("updated DTO");
          final ExampleDTO updatedExampleDTO = service.update(savedExampleDTO);
          final ExampleDTO foundExampleDTO = service.find(savedExampleDTO.getId());

            assertThat(foundExampleDTO.getData()).isEqualTo(updatedExampleDTO.getData());*/
     }

      @Test
      public void deletes() {
           /*final ExampleDTO savedExampleDTO = service.save(exampleDTO);
           assertThat(service.find(savedExampleDTO.getId())).isNotNull();
           service.delete(savedExampleDTO.getId());

           assertThat(service.find(savedExampleDTO.getId())).isNull();*/
      }
}
