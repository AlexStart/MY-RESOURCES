package com.samsolutions.mongo.persistence.entity;

import lombok.Data;
import org.springframework.data.annotation.Id;


/**
 * @author The Great Tool
 * @since 24.06.2017
 */
@Data
public class Example {

    @Id
    private String id;

    private String data;
}
