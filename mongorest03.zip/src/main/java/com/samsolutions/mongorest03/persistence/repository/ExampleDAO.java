package com.samsolutions.mongorest03.persistence.repository;

import com.samsolutions.mongorest03.persistence.entity.Example;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

/**
 * @author The Great Tool
 * @since 27.06.2017
 */
@RepositoryRestResource(collectionResourceRel = "examples", path = "examples")
public interface ExampleDAO extends MongoRepository<Example, String> {
}