package com.samsolutions.mongorest03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mongorest03Application {

	public static void main(String[] args) {
		SpringApplication.run(Mongorest03Application.class, args);
	}
}
