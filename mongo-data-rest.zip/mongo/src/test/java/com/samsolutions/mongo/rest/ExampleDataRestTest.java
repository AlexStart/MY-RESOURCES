package com.samsolutions.mongo.rest;

import com.samsolutions.mongo.persistence.entity.Example;
import com.samsolutions.mongo.persistence.repository.ExampleDAO;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * @author The Great Tool
 * @since 24.06.2017
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class ExampleDataRestTest {

    @Autowired
    ExampleDAO dataRest;

    Example example;

    @Before
    public void setUp() {
        example = new Example();
        example.setData("some data");

        dataRest.deleteAll();
    }

    @Test
    public void restCreate() {
        dao.save(example);

        assertThat(dao.findAll()).containsOnly(example);
    }

    @Test
    public void restRead() {
        dao.save(example);

        final Example saved = dao.findOne(example.getId());
        assertThat(saved).isEqualTo(example);
    }

    @Test
    public void restReadAll() {
        dao.save(example);

        final Example saved = dao.findOne(example.getId());
        assertThat(saved).isEqualTo(example);
    }

    @Test
    public void restUpdate() {
        dao.save(example);

        example.setData("updated");
        dao.save(example);

        final Example saved = dao.findOne(example.getId());
        assertThat(saved).isEqualTo(example);
    }

    @Test
    public void restDelete() {
        dao.save(example);
        assertThat(dao.findAll()).containsOnly(example);

        dao.delete(example);
        assertThat(dao.count()).isZero();
    }

    @Test
    public void restDeleteAll() {
        dao.save(example);
        assertThat(dao.findAll()).containsOnly(example);

        dao.delete(example);
        assertThat(dao.count()).isZero();
    }

    @After
    public void tearDown() {
        dataRest.deleteAll();
    }

}
