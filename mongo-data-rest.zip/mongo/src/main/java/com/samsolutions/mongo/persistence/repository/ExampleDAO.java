package com.samsolutions.mongo.persistence.repository;

import com.samsolutions.mongo.persistence.entity.Example;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.stereotype.Repository;

/**
 * @author The Great Tool
 * @since 24.06.2017
 */
@RepositoryRestResource(collectionResourceRel = "examples", path = "examples")
public interface ExampleDAO extends MongoRepository<Example, String> {
}