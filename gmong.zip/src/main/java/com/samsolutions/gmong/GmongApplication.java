package com.samsolutions.gmong;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GmongApplication {

	public static void main(String[] args) {
		SpringApplication.run(GmongApplication.class, args);
	}
}
