package com.samsolutions.gmong.persistence.repository;

import com.samsolutions.gmong.persistence.entity.Example;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

/**
 * @author The Great Tool
 * @since 22.06.2017
 */
@Repository
public interface ExampleDAO extends MongoRepository<Example, String> {
}